-- Copyright (C) 1991-2013 Altera Corporation
-- Your use of Altera Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Altera Program License 
-- Subscription Agreement, Altera MegaCore Function License 
-- Agreement, or other applicable license agreement, including, 
-- without limitation, that your use is for the sole purpose of 
-- programming logic devices manufactured by Altera and sold by 
-- Altera or its authorized distributors.  Please refer to the 
-- applicable agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus II 64-Bit"
-- VERSION "Version 13.1.0 Build 162 10/23/2013 SJ Web Edition"

-- DATE "10/12/2026 12:33:27"

-- 
-- Device: Altera EP3C16F484C6 Package FBGA484
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY ALTERA;
LIBRARY CYCLONEIII;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE CYCLONEIII.CYCLONEIII_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	morse IS
    PORT (
	CLOCK_50 : IN std_logic;
	KEY : IN std_logic_vector(1 DOWNTO 0);
	SW : IN std_logic_vector(2 DOWNTO 0);
	LEDG : OUT std_logic_vector(0 DOWNTO 0)
	);
END morse;

-- Design Ports Information
-- LEDG[0]	=>  Location: PIN_F11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- CLOCK_50	=>  Location: PIN_G2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- KEY[0]	=>  Location: PIN_G1,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- KEY[1]	=>  Location: PIN_E12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SW[0]	=>  Location: PIN_B14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SW[1]	=>  Location: PIN_A14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SW[2]	=>  Location: PIN_C13,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF morse IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_CLOCK_50 : std_logic;
SIGNAL ww_KEY : std_logic_vector(1 DOWNTO 0);
SIGNAL ww_SW : std_logic_vector(2 DOWNTO 0);
SIGNAL ww_LEDG : std_logic_vector(0 DOWNTO 0);
SIGNAL \CLOCK_50~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \KEY[0]~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \LEDG[0]~output_o\ : std_logic;
SIGNAL \CLOCK_50~input_o\ : std_logic;
SIGNAL \CLOCK_50~inputclkctrl_outclk\ : std_logic;
SIGNAL \cnt[0]~25_combout\ : std_logic;
SIGNAL \KEY[0]~input_o\ : std_logic;
SIGNAL \KEY[0]~inputclkctrl_outclk\ : std_logic;
SIGNAL \cnt[13]~27_combout\ : std_logic;
SIGNAL \cnt[0]~26\ : std_logic;
SIGNAL \cnt[1]~28_combout\ : std_logic;
SIGNAL \cnt[1]~29\ : std_logic;
SIGNAL \cnt[2]~30_combout\ : std_logic;
SIGNAL \cnt[2]~31\ : std_logic;
SIGNAL \cnt[3]~32_combout\ : std_logic;
SIGNAL \cnt[3]~33\ : std_logic;
SIGNAL \cnt[4]~34_combout\ : std_logic;
SIGNAL \cnt[4]~35\ : std_logic;
SIGNAL \cnt[5]~36_combout\ : std_logic;
SIGNAL \cnt[5]~37\ : std_logic;
SIGNAL \cnt[6]~38_combout\ : std_logic;
SIGNAL \cnt[6]~39\ : std_logic;
SIGNAL \cnt[7]~40_combout\ : std_logic;
SIGNAL \cnt[7]~41\ : std_logic;
SIGNAL \cnt[8]~42_combout\ : std_logic;
SIGNAL \cnt[8]~43\ : std_logic;
SIGNAL \cnt[9]~44_combout\ : std_logic;
SIGNAL \cnt[9]~45\ : std_logic;
SIGNAL \cnt[10]~46_combout\ : std_logic;
SIGNAL \cnt[10]~47\ : std_logic;
SIGNAL \cnt[11]~48_combout\ : std_logic;
SIGNAL \cnt[11]~49\ : std_logic;
SIGNAL \cnt[12]~50_combout\ : std_logic;
SIGNAL \cnt[12]~51\ : std_logic;
SIGNAL \cnt[13]~52_combout\ : std_logic;
SIGNAL \cnt[13]~53\ : std_logic;
SIGNAL \cnt[14]~54_combout\ : std_logic;
SIGNAL \cnt[14]~55\ : std_logic;
SIGNAL \cnt[15]~56_combout\ : std_logic;
SIGNAL \cnt[15]~57\ : std_logic;
SIGNAL \cnt[16]~58_combout\ : std_logic;
SIGNAL \cnt[16]~59\ : std_logic;
SIGNAL \cnt[17]~60_combout\ : std_logic;
SIGNAL \cnt[17]~61\ : std_logic;
SIGNAL \cnt[18]~62_combout\ : std_logic;
SIGNAL \cnt[18]~63\ : std_logic;
SIGNAL \cnt[19]~64_combout\ : std_logic;
SIGNAL \cnt[19]~65\ : std_logic;
SIGNAL \cnt[20]~66_combout\ : std_logic;
SIGNAL \cnt[20]~67\ : std_logic;
SIGNAL \cnt[21]~68_combout\ : std_logic;
SIGNAL \cnt[21]~69\ : std_logic;
SIGNAL \cnt[22]~70_combout\ : std_logic;
SIGNAL \cnt[22]~71\ : std_logic;
SIGNAL \cnt[23]~72_combout\ : std_logic;
SIGNAL \cnt[23]~73\ : std_logic;
SIGNAL \cnt[24]~74_combout\ : std_logic;
SIGNAL \Equal0~6_combout\ : std_logic;
SIGNAL \Equal0~5_combout\ : std_logic;
SIGNAL \Equal0~1_combout\ : std_logic;
SIGNAL \Equal0~2_combout\ : std_logic;
SIGNAL \Equal0~0_combout\ : std_logic;
SIGNAL \Equal0~3_combout\ : std_logic;
SIGNAL \Equal0~4_combout\ : std_logic;
SIGNAL \Equal0~7_combout\ : std_logic;
SIGNAL \Selector13~1_combout\ : std_logic;
SIGNAL \Selector12~1_combout\ : std_logic;
SIGNAL \Selector13~2_combout\ : std_logic;
SIGNAL \Selector13~3_combout\ : std_logic;
SIGNAL \SW[0]~input_o\ : std_logic;
SIGNAL \SW[1]~input_o\ : std_logic;
SIGNAL \SW[2]~input_o\ : std_logic;
SIGNAL \Selector7~0_combout\ : std_logic;
SIGNAL \shreg[3]~0_combout\ : std_logic;
SIGNAL \Selector10~1_combout\ : std_logic;
SIGNAL \Selector6~0_combout\ : std_logic;
SIGNAL \Selector5~0_combout\ : std_logic;
SIGNAL \Selector5~1_combout\ : std_logic;
SIGNAL \Selector13~0_combout\ : std_logic;
SIGNAL \Selector12~0_combout\ : std_logic;
SIGNAL \Selector12~2_combout\ : std_logic;
SIGNAL \process_2~0_combout\ : std_logic;
SIGNAL \Selector3~1_combout\ : std_logic;
SIGNAL \KEY[1]~input_o\ : std_logic;
SIGNAL \Selector0~0_combout\ : std_logic;
SIGNAL \state.IDLE~q\ : std_logic;
SIGNAL \Selector3~2_combout\ : std_logic;
SIGNAL \Selector2~1_combout\ : std_logic;
SIGNAL \Selector3~3_combout\ : std_logic;
SIGNAL \Selector3~4_combout\ : std_logic;
SIGNAL \state.OFF_ST~q\ : std_logic;
SIGNAL \Selector9~0_combout\ : std_logic;
SIGNAL \remain[2]~0_combout\ : std_logic;
SIGNAL \Selector10~0_combout\ : std_logic;
SIGNAL \remain[1]~1_combout\ : std_logic;
SIGNAL \Selector11~0_combout\ : std_logic;
SIGNAL \remain[0]~2_combout\ : std_logic;
SIGNAL \remain[0]~_wirecell_combout\ : std_logic;
SIGNAL \Add2~1_combout\ : std_logic;
SIGNAL \Add2~0_combout\ : std_logic;
SIGNAL \Equal2~0_combout\ : std_logic;
SIGNAL \Selector4~0_combout\ : std_logic;
SIGNAL \Selector2~2_combout\ : std_logic;
SIGNAL \Selector2~3_combout\ : std_logic;
SIGNAL \state.WAIT_REL~q\ : std_logic;
SIGNAL \Selector3~0_combout\ : std_logic;
SIGNAL \Selector1~0_combout\ : std_logic;
SIGNAL \state.LOAD~q\ : std_logic;
SIGNAL \Selector2~0_combout\ : std_logic;
SIGNAL \state.ON_ST~q\ : std_logic;
SIGNAL shreg : std_logic_vector(3 DOWNTO 0);
SIGNAL remain : std_logic_vector(2 DOWNTO 0);
SIGNAL dur : std_logic_vector(1 DOWNTO 0);
SIGNAL cnt : std_logic_vector(24 DOWNTO 0);

BEGIN

ww_CLOCK_50 <= CLOCK_50;
ww_KEY <= KEY;
ww_SW <= SW;
LEDG <= ww_LEDG;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\CLOCK_50~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \CLOCK_50~input_o\);

\KEY[0]~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \KEY[0]~input_o\);

-- Location: IOOBUF_X21_Y29_N30
\LEDG[0]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \state.ON_ST~q\,
	devoe => ww_devoe,
	o => \LEDG[0]~output_o\);

-- Location: IOIBUF_X0_Y14_N1
\CLOCK_50~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_CLOCK_50,
	o => \CLOCK_50~input_o\);

-- Location: CLKCTRL_G4
\CLOCK_50~inputclkctrl\ : cycloneiii_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \CLOCK_50~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \CLOCK_50~inputclkctrl_outclk\);

-- Location: LCCOMB_X22_Y28_N8
\cnt[0]~25\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt[0]~25_combout\ = cnt(0) $ (VCC)
-- \cnt[0]~26\ = CARRY(cnt(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => cnt(0),
	datad => VCC,
	combout => \cnt[0]~25_combout\,
	cout => \cnt[0]~26\);

-- Location: IOIBUF_X0_Y14_N8
\KEY[0]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_KEY(0),
	o => \KEY[0]~input_o\);

-- Location: CLKCTRL_G2
\KEY[0]~inputclkctrl\ : cycloneiii_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \KEY[0]~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \KEY[0]~inputclkctrl_outclk\);

-- Location: LCCOMB_X23_Y27_N0
\cnt[13]~27\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt[13]~27_combout\ = ((!\state.ON_ST~q\ & !\state.OFF_ST~q\)) # (!\Equal0~7_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \state.ON_ST~q\,
	datac => \state.OFF_ST~q\,
	datad => \Equal0~7_combout\,
	combout => \cnt[13]~27_combout\);

-- Location: FF_X22_Y28_N9
\cnt[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \cnt[0]~25_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	sclr => \cnt[13]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cnt(0));

-- Location: LCCOMB_X22_Y28_N10
\cnt[1]~28\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt[1]~28_combout\ = (cnt(1) & (!\cnt[0]~26\)) # (!cnt(1) & ((\cnt[0]~26\) # (GND)))
-- \cnt[1]~29\ = CARRY((!\cnt[0]~26\) # (!cnt(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => cnt(1),
	datad => VCC,
	cin => \cnt[0]~26\,
	combout => \cnt[1]~28_combout\,
	cout => \cnt[1]~29\);

-- Location: FF_X22_Y28_N11
\cnt[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \cnt[1]~28_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	sclr => \cnt[13]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cnt(1));

-- Location: LCCOMB_X22_Y28_N12
\cnt[2]~30\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt[2]~30_combout\ = (cnt(2) & (\cnt[1]~29\ $ (GND))) # (!cnt(2) & (!\cnt[1]~29\ & VCC))
-- \cnt[2]~31\ = CARRY((cnt(2) & !\cnt[1]~29\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => cnt(2),
	datad => VCC,
	cin => \cnt[1]~29\,
	combout => \cnt[2]~30_combout\,
	cout => \cnt[2]~31\);

-- Location: FF_X22_Y28_N13
\cnt[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \cnt[2]~30_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	sclr => \cnt[13]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cnt(2));

-- Location: LCCOMB_X22_Y28_N14
\cnt[3]~32\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt[3]~32_combout\ = (cnt(3) & (!\cnt[2]~31\)) # (!cnt(3) & ((\cnt[2]~31\) # (GND)))
-- \cnt[3]~33\ = CARRY((!\cnt[2]~31\) # (!cnt(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => cnt(3),
	datad => VCC,
	cin => \cnt[2]~31\,
	combout => \cnt[3]~32_combout\,
	cout => \cnt[3]~33\);

-- Location: FF_X22_Y28_N15
\cnt[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \cnt[3]~32_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	sclr => \cnt[13]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cnt(3));

-- Location: LCCOMB_X22_Y28_N16
\cnt[4]~34\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt[4]~34_combout\ = (cnt(4) & (\cnt[3]~33\ $ (GND))) # (!cnt(4) & (!\cnt[3]~33\ & VCC))
-- \cnt[4]~35\ = CARRY((cnt(4) & !\cnt[3]~33\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => cnt(4),
	datad => VCC,
	cin => \cnt[3]~33\,
	combout => \cnt[4]~34_combout\,
	cout => \cnt[4]~35\);

-- Location: FF_X22_Y28_N17
\cnt[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \cnt[4]~34_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	sclr => \cnt[13]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cnt(4));

-- Location: LCCOMB_X22_Y28_N18
\cnt[5]~36\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt[5]~36_combout\ = (cnt(5) & (!\cnt[4]~35\)) # (!cnt(5) & ((\cnt[4]~35\) # (GND)))
-- \cnt[5]~37\ = CARRY((!\cnt[4]~35\) # (!cnt(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => cnt(5),
	datad => VCC,
	cin => \cnt[4]~35\,
	combout => \cnt[5]~36_combout\,
	cout => \cnt[5]~37\);

-- Location: FF_X22_Y28_N19
\cnt[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \cnt[5]~36_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	sclr => \cnt[13]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cnt(5));

-- Location: LCCOMB_X22_Y28_N20
\cnt[6]~38\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt[6]~38_combout\ = (cnt(6) & (\cnt[5]~37\ $ (GND))) # (!cnt(6) & (!\cnt[5]~37\ & VCC))
-- \cnt[6]~39\ = CARRY((cnt(6) & !\cnt[5]~37\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => cnt(6),
	datad => VCC,
	cin => \cnt[5]~37\,
	combout => \cnt[6]~38_combout\,
	cout => \cnt[6]~39\);

-- Location: FF_X22_Y28_N21
\cnt[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \cnt[6]~38_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	sclr => \cnt[13]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cnt(6));

-- Location: LCCOMB_X22_Y28_N22
\cnt[7]~40\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt[7]~40_combout\ = (cnt(7) & (!\cnt[6]~39\)) # (!cnt(7) & ((\cnt[6]~39\) # (GND)))
-- \cnt[7]~41\ = CARRY((!\cnt[6]~39\) # (!cnt(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => cnt(7),
	datad => VCC,
	cin => \cnt[6]~39\,
	combout => \cnt[7]~40_combout\,
	cout => \cnt[7]~41\);

-- Location: FF_X22_Y28_N23
\cnt[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \cnt[7]~40_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	sclr => \cnt[13]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cnt(7));

-- Location: LCCOMB_X22_Y28_N24
\cnt[8]~42\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt[8]~42_combout\ = (cnt(8) & (\cnt[7]~41\ $ (GND))) # (!cnt(8) & (!\cnt[7]~41\ & VCC))
-- \cnt[8]~43\ = CARRY((cnt(8) & !\cnt[7]~41\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => cnt(8),
	datad => VCC,
	cin => \cnt[7]~41\,
	combout => \cnt[8]~42_combout\,
	cout => \cnt[8]~43\);

-- Location: FF_X22_Y28_N25
\cnt[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \cnt[8]~42_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	sclr => \cnt[13]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cnt(8));

-- Location: LCCOMB_X22_Y28_N26
\cnt[9]~44\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt[9]~44_combout\ = (cnt(9) & (!\cnt[8]~43\)) # (!cnt(9) & ((\cnt[8]~43\) # (GND)))
-- \cnt[9]~45\ = CARRY((!\cnt[8]~43\) # (!cnt(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => cnt(9),
	datad => VCC,
	cin => \cnt[8]~43\,
	combout => \cnt[9]~44_combout\,
	cout => \cnt[9]~45\);

-- Location: FF_X22_Y28_N27
\cnt[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \cnt[9]~44_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	sclr => \cnt[13]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cnt(9));

-- Location: LCCOMB_X22_Y28_N28
\cnt[10]~46\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt[10]~46_combout\ = (cnt(10) & (\cnt[9]~45\ $ (GND))) # (!cnt(10) & (!\cnt[9]~45\ & VCC))
-- \cnt[10]~47\ = CARRY((cnt(10) & !\cnt[9]~45\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => cnt(10),
	datad => VCC,
	cin => \cnt[9]~45\,
	combout => \cnt[10]~46_combout\,
	cout => \cnt[10]~47\);

-- Location: FF_X22_Y28_N29
\cnt[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \cnt[10]~46_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	sclr => \cnt[13]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cnt(10));

-- Location: LCCOMB_X22_Y28_N30
\cnt[11]~48\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt[11]~48_combout\ = (cnt(11) & (!\cnt[10]~47\)) # (!cnt(11) & ((\cnt[10]~47\) # (GND)))
-- \cnt[11]~49\ = CARRY((!\cnt[10]~47\) # (!cnt(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => cnt(11),
	datad => VCC,
	cin => \cnt[10]~47\,
	combout => \cnt[11]~48_combout\,
	cout => \cnt[11]~49\);

-- Location: FF_X22_Y28_N31
\cnt[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \cnt[11]~48_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	sclr => \cnt[13]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cnt(11));

-- Location: LCCOMB_X22_Y27_N0
\cnt[12]~50\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt[12]~50_combout\ = (cnt(12) & (\cnt[11]~49\ $ (GND))) # (!cnt(12) & (!\cnt[11]~49\ & VCC))
-- \cnt[12]~51\ = CARRY((cnt(12) & !\cnt[11]~49\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => cnt(12),
	datad => VCC,
	cin => \cnt[11]~49\,
	combout => \cnt[12]~50_combout\,
	cout => \cnt[12]~51\);

-- Location: FF_X22_Y27_N1
\cnt[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \cnt[12]~50_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	sclr => \cnt[13]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cnt(12));

-- Location: LCCOMB_X22_Y27_N2
\cnt[13]~52\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt[13]~52_combout\ = (cnt(13) & (!\cnt[12]~51\)) # (!cnt(13) & ((\cnt[12]~51\) # (GND)))
-- \cnt[13]~53\ = CARRY((!\cnt[12]~51\) # (!cnt(13)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => cnt(13),
	datad => VCC,
	cin => \cnt[12]~51\,
	combout => \cnt[13]~52_combout\,
	cout => \cnt[13]~53\);

-- Location: FF_X22_Y27_N3
\cnt[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \cnt[13]~52_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	sclr => \cnt[13]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cnt(13));

-- Location: LCCOMB_X22_Y27_N4
\cnt[14]~54\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt[14]~54_combout\ = (cnt(14) & (\cnt[13]~53\ $ (GND))) # (!cnt(14) & (!\cnt[13]~53\ & VCC))
-- \cnt[14]~55\ = CARRY((cnt(14) & !\cnt[13]~53\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => cnt(14),
	datad => VCC,
	cin => \cnt[13]~53\,
	combout => \cnt[14]~54_combout\,
	cout => \cnt[14]~55\);

-- Location: FF_X22_Y27_N5
\cnt[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \cnt[14]~54_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	sclr => \cnt[13]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cnt(14));

-- Location: LCCOMB_X22_Y27_N6
\cnt[15]~56\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt[15]~56_combout\ = (cnt(15) & (!\cnt[14]~55\)) # (!cnt(15) & ((\cnt[14]~55\) # (GND)))
-- \cnt[15]~57\ = CARRY((!\cnt[14]~55\) # (!cnt(15)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => cnt(15),
	datad => VCC,
	cin => \cnt[14]~55\,
	combout => \cnt[15]~56_combout\,
	cout => \cnt[15]~57\);

-- Location: FF_X22_Y27_N7
\cnt[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \cnt[15]~56_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	sclr => \cnt[13]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cnt(15));

-- Location: LCCOMB_X22_Y27_N8
\cnt[16]~58\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt[16]~58_combout\ = (cnt(16) & (\cnt[15]~57\ $ (GND))) # (!cnt(16) & (!\cnt[15]~57\ & VCC))
-- \cnt[16]~59\ = CARRY((cnt(16) & !\cnt[15]~57\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => cnt(16),
	datad => VCC,
	cin => \cnt[15]~57\,
	combout => \cnt[16]~58_combout\,
	cout => \cnt[16]~59\);

-- Location: FF_X22_Y27_N9
\cnt[16]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \cnt[16]~58_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	sclr => \cnt[13]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cnt(16));

-- Location: LCCOMB_X22_Y27_N10
\cnt[17]~60\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt[17]~60_combout\ = (cnt(17) & (!\cnt[16]~59\)) # (!cnt(17) & ((\cnt[16]~59\) # (GND)))
-- \cnt[17]~61\ = CARRY((!\cnt[16]~59\) # (!cnt(17)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => cnt(17),
	datad => VCC,
	cin => \cnt[16]~59\,
	combout => \cnt[17]~60_combout\,
	cout => \cnt[17]~61\);

-- Location: FF_X22_Y27_N11
\cnt[17]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \cnt[17]~60_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	sclr => \cnt[13]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cnt(17));

-- Location: LCCOMB_X22_Y27_N12
\cnt[18]~62\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt[18]~62_combout\ = (cnt(18) & (\cnt[17]~61\ $ (GND))) # (!cnt(18) & (!\cnt[17]~61\ & VCC))
-- \cnt[18]~63\ = CARRY((cnt(18) & !\cnt[17]~61\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => cnt(18),
	datad => VCC,
	cin => \cnt[17]~61\,
	combout => \cnt[18]~62_combout\,
	cout => \cnt[18]~63\);

-- Location: FF_X22_Y27_N13
\cnt[18]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \cnt[18]~62_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	sclr => \cnt[13]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cnt(18));

-- Location: LCCOMB_X22_Y27_N14
\cnt[19]~64\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt[19]~64_combout\ = (cnt(19) & (!\cnt[18]~63\)) # (!cnt(19) & ((\cnt[18]~63\) # (GND)))
-- \cnt[19]~65\ = CARRY((!\cnt[18]~63\) # (!cnt(19)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => cnt(19),
	datad => VCC,
	cin => \cnt[18]~63\,
	combout => \cnt[19]~64_combout\,
	cout => \cnt[19]~65\);

-- Location: FF_X22_Y27_N15
\cnt[19]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \cnt[19]~64_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	sclr => \cnt[13]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cnt(19));

-- Location: LCCOMB_X22_Y27_N16
\cnt[20]~66\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt[20]~66_combout\ = (cnt(20) & (\cnt[19]~65\ $ (GND))) # (!cnt(20) & (!\cnt[19]~65\ & VCC))
-- \cnt[20]~67\ = CARRY((cnt(20) & !\cnt[19]~65\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => cnt(20),
	datad => VCC,
	cin => \cnt[19]~65\,
	combout => \cnt[20]~66_combout\,
	cout => \cnt[20]~67\);

-- Location: FF_X22_Y27_N17
\cnt[20]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \cnt[20]~66_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	sclr => \cnt[13]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cnt(20));

-- Location: LCCOMB_X22_Y27_N18
\cnt[21]~68\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt[21]~68_combout\ = (cnt(21) & (!\cnt[20]~67\)) # (!cnt(21) & ((\cnt[20]~67\) # (GND)))
-- \cnt[21]~69\ = CARRY((!\cnt[20]~67\) # (!cnt(21)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => cnt(21),
	datad => VCC,
	cin => \cnt[20]~67\,
	combout => \cnt[21]~68_combout\,
	cout => \cnt[21]~69\);

-- Location: FF_X22_Y27_N19
\cnt[21]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \cnt[21]~68_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	sclr => \cnt[13]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cnt(21));

-- Location: LCCOMB_X22_Y27_N20
\cnt[22]~70\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt[22]~70_combout\ = (cnt(22) & (\cnt[21]~69\ $ (GND))) # (!cnt(22) & (!\cnt[21]~69\ & VCC))
-- \cnt[22]~71\ = CARRY((cnt(22) & !\cnt[21]~69\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => cnt(22),
	datad => VCC,
	cin => \cnt[21]~69\,
	combout => \cnt[22]~70_combout\,
	cout => \cnt[22]~71\);

-- Location: FF_X22_Y27_N21
\cnt[22]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \cnt[22]~70_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	sclr => \cnt[13]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cnt(22));

-- Location: LCCOMB_X22_Y27_N22
\cnt[23]~72\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt[23]~72_combout\ = (cnt(23) & (!\cnt[22]~71\)) # (!cnt(23) & ((\cnt[22]~71\) # (GND)))
-- \cnt[23]~73\ = CARRY((!\cnt[22]~71\) # (!cnt(23)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => cnt(23),
	datad => VCC,
	cin => \cnt[22]~71\,
	combout => \cnt[23]~72_combout\,
	cout => \cnt[23]~73\);

-- Location: FF_X22_Y27_N23
\cnt[23]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \cnt[23]~72_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	sclr => \cnt[13]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cnt(23));

-- Location: LCCOMB_X22_Y27_N24
\cnt[24]~74\ : cycloneiii_lcell_comb
-- Equation(s):
-- \cnt[24]~74_combout\ = \cnt[23]~73\ $ (!cnt(24))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => cnt(24),
	cin => \cnt[23]~73\,
	combout => \cnt[24]~74_combout\);

-- Location: FF_X22_Y27_N25
\cnt[24]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \cnt[24]~74_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	sclr => \cnt[13]~27_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => cnt(24));

-- Location: LCCOMB_X22_Y27_N28
\Equal0~6\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Equal0~6_combout\ = (cnt(23)) # (((!cnt(22)) # (!cnt(20))) # (!cnt(21)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => cnt(23),
	datab => cnt(21),
	datac => cnt(20),
	datad => cnt(22),
	combout => \Equal0~6_combout\);

-- Location: LCCOMB_X23_Y27_N28
\Equal0~5\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Equal0~5_combout\ = (((cnt(17)) # (!cnt(18))) # (!cnt(19))) # (!cnt(16))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111011111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => cnt(16),
	datab => cnt(19),
	datac => cnt(17),
	datad => cnt(18),
	combout => \Equal0~5_combout\);

-- Location: LCCOMB_X22_Y28_N6
\Equal0~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Equal0~1_combout\ = (cnt(7)) # (((cnt(6)) # (!cnt(4))) # (!cnt(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => cnt(7),
	datab => cnt(5),
	datac => cnt(6),
	datad => cnt(4),
	combout => \Equal0~1_combout\);

-- Location: LCCOMB_X22_Y28_N0
\Equal0~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Equal0~2_combout\ = ((cnt(8)) # ((cnt(9)) # (cnt(10)))) # (!cnt(11))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => cnt(11),
	datab => cnt(8),
	datac => cnt(9),
	datad => cnt(10),
	combout => \Equal0~2_combout\);

-- Location: LCCOMB_X22_Y28_N4
\Equal0~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Equal0~0_combout\ = (((!cnt(2)) # (!cnt(0))) # (!cnt(3))) # (!cnt(1))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => cnt(1),
	datab => cnt(3),
	datac => cnt(0),
	datad => cnt(2),
	combout => \Equal0~0_combout\);

-- Location: LCCOMB_X22_Y27_N26
\Equal0~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Equal0~3_combout\ = (cnt(15)) # (((!cnt(13)) # (!cnt(14))) # (!cnt(12)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => cnt(15),
	datab => cnt(12),
	datac => cnt(14),
	datad => cnt(13),
	combout => \Equal0~3_combout\);

-- Location: LCCOMB_X22_Y28_N2
\Equal0~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Equal0~4_combout\ = (\Equal0~1_combout\) # ((\Equal0~2_combout\) # ((\Equal0~0_combout\) # (\Equal0~3_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Equal0~1_combout\,
	datab => \Equal0~2_combout\,
	datac => \Equal0~0_combout\,
	datad => \Equal0~3_combout\,
	combout => \Equal0~4_combout\);

-- Location: LCCOMB_X22_Y27_N30
\Equal0~7\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Equal0~7_combout\ = ((\Equal0~6_combout\) # ((\Equal0~5_combout\) # (\Equal0~4_combout\))) # (!cnt(24))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => cnt(24),
	datab => \Equal0~6_combout\,
	datac => \Equal0~5_combout\,
	datad => \Equal0~4_combout\,
	combout => \Equal0~7_combout\);

-- Location: LCCOMB_X23_Y27_N22
\Selector13~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector13~1_combout\ = (\state.ON_ST~q\ & \Equal0~7_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \state.ON_ST~q\,
	datad => \Equal0~7_combout\,
	combout => \Selector13~1_combout\);

-- Location: LCCOMB_X23_Y27_N4
\Selector12~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector12~1_combout\ = (!\state.ON_ST~q\ & !\state.LOAD~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010100000101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \state.ON_ST~q\,
	datac => \state.LOAD~q\,
	combout => \Selector12~1_combout\);

-- Location: LCCOMB_X23_Y27_N18
\Selector13~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector13~2_combout\ = (!dur(0) & (!\process_2~0_combout\ & (\state.ON_ST~q\ & !\Equal0~7_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => dur(0),
	datab => \process_2~0_combout\,
	datac => \state.ON_ST~q\,
	datad => \Equal0~7_combout\,
	combout => \Selector13~2_combout\);

-- Location: LCCOMB_X23_Y27_N2
\Selector13~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector13~3_combout\ = (\Selector13~2_combout\) # ((dur(0) & ((\Selector13~1_combout\) # (\Selector12~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Selector13~1_combout\,
	datab => \Selector12~1_combout\,
	datac => dur(0),
	datad => \Selector13~2_combout\,
	combout => \Selector13~3_combout\);

-- Location: FF_X23_Y27_N3
\dur[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \Selector13~3_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => dur(0));

-- Location: IOIBUF_X23_Y29_N29
\SW[0]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_SW(0),
	o => \SW[0]~input_o\);

-- Location: IOIBUF_X23_Y29_N22
\SW[1]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_SW(1),
	o => \SW[1]~input_o\);

-- Location: IOIBUF_X23_Y29_N1
\SW[2]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_SW(2),
	o => \SW[2]~input_o\);

-- Location: LCCOMB_X24_Y27_N28
\Selector7~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector7~0_combout\ = (!\state.OFF_ST~q\ & ((\SW[1]~input_o\ & (!\SW[2]~input_o\ & !\SW[0]~input_o\)) # (!\SW[1]~input_o\ & (\SW[2]~input_o\ & \SW[0]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000000000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \state.OFF_ST~q\,
	datab => \SW[1]~input_o\,
	datac => \SW[2]~input_o\,
	datad => \SW[0]~input_o\,
	combout => \Selector7~0_combout\);

-- Location: LCCOMB_X24_Y27_N8
\shreg[3]~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \shreg[3]~0_combout\ = (\state.OFF_ST~q\ & ((!\Equal0~7_combout\))) # (!\state.OFF_ST~q\ & (\state.LOAD~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \state.LOAD~q\,
	datac => \Equal0~7_combout\,
	datad => \state.OFF_ST~q\,
	combout => \shreg[3]~0_combout\);

-- Location: FF_X24_Y27_N29
\shreg[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \Selector7~0_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	ena => \shreg[3]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => shreg(1));

-- Location: LCCOMB_X24_Y27_N20
\Selector10~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector10~1_combout\ = \SW[1]~input_o\ $ (\SW[2]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \SW[1]~input_o\,
	datac => \SW[2]~input_o\,
	combout => \Selector10~1_combout\);

-- Location: LCCOMB_X24_Y27_N22
\Selector6~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector6~0_combout\ = (\state.OFF_ST~q\ & (((shreg(1))))) # (!\state.OFF_ST~q\ & (!\SW[0]~input_o\ & ((!\Selector10~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010110001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \state.OFF_ST~q\,
	datab => \SW[0]~input_o\,
	datac => shreg(1),
	datad => \Selector10~1_combout\,
	combout => \Selector6~0_combout\);

-- Location: FF_X24_Y27_N23
\shreg[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \Selector6~0_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	ena => \shreg[3]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => shreg(2));

-- Location: LCCOMB_X24_Y27_N12
\Selector5~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector5~0_combout\ = (!\state.OFF_ST~q\ & ((\SW[0]~input_o\ & ((!\SW[2]~input_o\))) # (!\SW[0]~input_o\ & (\SW[1]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010101000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \state.OFF_ST~q\,
	datab => \SW[1]~input_o\,
	datac => \SW[2]~input_o\,
	datad => \SW[0]~input_o\,
	combout => \Selector5~0_combout\);

-- Location: LCCOMB_X24_Y27_N24
\Selector5~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector5~1_combout\ = (\Selector5~0_combout\) # ((\state.OFF_ST~q\ & shreg(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \state.OFF_ST~q\,
	datac => shreg(2),
	datad => \Selector5~0_combout\,
	combout => \Selector5~1_combout\);

-- Location: FF_X24_Y27_N25
\shreg[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \Selector5~1_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	ena => \shreg[3]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => shreg(3));

-- Location: LCCOMB_X21_Y27_N12
\Selector13~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector13~0_combout\ = (\state.ON_ST~q\ & !\Equal0~7_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \state.ON_ST~q\,
	datac => \Equal0~7_combout\,
	combout => \Selector13~0_combout\);

-- Location: LCCOMB_X21_Y27_N10
\Selector12~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector12~0_combout\ = (dur(0) & (!dur(1) & (shreg(3) & \Selector13~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => dur(0),
	datab => dur(1),
	datac => shreg(3),
	datad => \Selector13~0_combout\,
	combout => \Selector12~0_combout\);

-- Location: LCCOMB_X21_Y27_N28
\Selector12~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector12~2_combout\ = (\Selector12~0_combout\) # ((dur(1) & ((\Selector13~1_combout\) # (\Selector12~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Selector13~1_combout\,
	datab => \Selector12~1_combout\,
	datac => dur(1),
	datad => \Selector12~0_combout\,
	combout => \Selector12~2_combout\);

-- Location: FF_X21_Y27_N29
\dur[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \Selector12~2_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => dur(1));

-- Location: LCCOMB_X21_Y27_N6
\process_2~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \process_2~0_combout\ = ((dur(1) & !dur(0))) # (!shreg(3))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => dur(1),
	datac => shreg(3),
	datad => dur(0),
	combout => \process_2~0_combout\);

-- Location: LCCOMB_X21_Y27_N0
\Selector3~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector3~1_combout\ = (\process_2~0_combout\ & (\state.ON_ST~q\ & !\Equal0~7_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000100000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \process_2~0_combout\,
	datab => \state.ON_ST~q\,
	datac => \Equal0~7_combout\,
	combout => \Selector3~1_combout\);

-- Location: IOIBUF_X21_Y29_N15
\KEY[1]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_KEY(1),
	o => \KEY[1]~input_o\);

-- Location: LCCOMB_X21_Y27_N22
\Selector0~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector0~0_combout\ = ((!\state.WAIT_REL~q\ & \state.IDLE~q\)) # (!\KEY[1]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111010101110101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \KEY[1]~input_o\,
	datab => \state.WAIT_REL~q\,
	datac => \state.IDLE~q\,
	combout => \Selector0~0_combout\);

-- Location: FF_X21_Y27_N23
\state.IDLE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \Selector0~0_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \state.IDLE~q\);

-- Location: LCCOMB_X21_Y27_N14
\Selector3~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector3~2_combout\ = (!\KEY[1]~input_o\ & !\state.IDLE~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010100000101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \KEY[1]~input_o\,
	datac => \state.IDLE~q\,
	combout => \Selector3~2_combout\);

-- Location: LCCOMB_X21_Y27_N4
\Selector2~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector2~1_combout\ = (!\state.LOAD~q\ & ((\Equal0~7_combout\) # (!\state.OFF_ST~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \state.OFF_ST~q\,
	datac => \state.LOAD~q\,
	datad => \Equal0~7_combout\,
	combout => \Selector2~1_combout\);

-- Location: LCCOMB_X21_Y27_N16
\Selector3~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector3~3_combout\ = (\Selector3~2_combout\) # (((\process_2~0_combout\ & \Selector13~0_combout\)) # (!\Selector2~1_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111111001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \process_2~0_combout\,
	datab => \Selector3~2_combout\,
	datac => \Selector2~1_combout\,
	datad => \Selector13~0_combout\,
	combout => \Selector3~3_combout\);

-- Location: LCCOMB_X21_Y27_N8
\Selector3~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector3~4_combout\ = (!\Selector3~0_combout\ & ((\Selector3~3_combout\ & (\Selector3~1_combout\)) # (!\Selector3~3_combout\ & ((\state.OFF_ST~q\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100010001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Selector3~0_combout\,
	datab => \Selector3~1_combout\,
	datac => \state.OFF_ST~q\,
	datad => \Selector3~3_combout\,
	combout => \Selector3~4_combout\);

-- Location: FF_X21_Y27_N9
\state.OFF_ST\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \Selector3~4_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \state.OFF_ST~q\);

-- Location: LCCOMB_X24_Y27_N18
\Selector9~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector9~0_combout\ = \SW[1]~input_o\ $ (\SW[0]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \SW[1]~input_o\,
	datad => \SW[0]~input_o\,
	combout => \Selector9~0_combout\);

-- Location: LCCOMB_X24_Y27_N10
\remain[2]~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \remain[2]~0_combout\ = (\SW[2]~input_o\ & (\SW[0]~input_o\)) # (!\SW[2]~input_o\ & ((\Selector9~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SW[2]~input_o\,
	datab => \SW[0]~input_o\,
	datad => \Selector9~0_combout\,
	combout => \remain[2]~0_combout\);

-- Location: LCCOMB_X24_Y27_N6
\Selector10~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector10~0_combout\ = (!\SW[2]~input_o\ & \SW[0]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \SW[2]~input_o\,
	datad => \SW[0]~input_o\,
	combout => \Selector10~0_combout\);

-- Location: LCCOMB_X24_Y27_N16
\remain[1]~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \remain[1]~1_combout\ = (\Selector10~1_combout\ & (\Selector10~0_combout\)) # (!\Selector10~1_combout\ & ((!\SW[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000110011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Selector10~0_combout\,
	datab => \SW[0]~input_o\,
	datad => \Selector10~1_combout\,
	combout => \remain[1]~1_combout\);

-- Location: LCCOMB_X24_Y27_N2
\Selector11~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector11~0_combout\ = (\SW[1]~input_o\ & \SW[0]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \SW[1]~input_o\,
	datad => \SW[0]~input_o\,
	combout => \Selector11~0_combout\);

-- Location: LCCOMB_X24_Y27_N0
\remain[0]~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \remain[0]~2_combout\ = (\SW[2]~input_o\ & (!\SW[0]~input_o\)) # (!\SW[2]~input_o\ & ((\Selector11~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111011100100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SW[2]~input_o\,
	datab => \SW[0]~input_o\,
	datad => \Selector11~0_combout\,
	combout => \remain[0]~2_combout\);

-- Location: LCCOMB_X24_Y27_N26
\remain[0]~_wirecell\ : cycloneiii_lcell_comb
-- Equation(s):
-- \remain[0]~_wirecell_combout\ = !remain(0)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => remain(0),
	combout => \remain[0]~_wirecell_combout\);

-- Location: FF_X24_Y27_N1
\remain[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \remain[0]~2_combout\,
	asdata => \remain[0]~_wirecell_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	sload => \state.OFF_ST~q\,
	ena => \shreg[3]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => remain(0));

-- Location: LCCOMB_X24_Y27_N30
\Add2~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Add2~1_combout\ = remain(1) $ (!remain(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000110011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => remain(1),
	datad => remain(0),
	combout => \Add2~1_combout\);

-- Location: FF_X24_Y27_N17
\remain[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \remain[1]~1_combout\,
	asdata => \Add2~1_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	sload => \state.OFF_ST~q\,
	ena => \shreg[3]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => remain(1));

-- Location: LCCOMB_X24_Y27_N4
\Add2~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Add2~0_combout\ = remain(2) $ (((!remain(1) & !remain(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101010011001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => remain(2),
	datab => remain(1),
	datad => remain(0),
	combout => \Add2~0_combout\);

-- Location: FF_X24_Y27_N11
\remain[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \remain[2]~0_combout\,
	asdata => \Add2~0_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	sload => \state.OFF_ST~q\,
	ena => \shreg[3]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => remain(2));

-- Location: LCCOMB_X24_Y27_N14
\Equal2~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Equal2~0_combout\ = (!remain(2) & (remain(0) & !remain(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000001000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => remain(2),
	datab => remain(0),
	datad => remain(1),
	combout => \Equal2~0_combout\);

-- Location: LCCOMB_X21_Y27_N2
\Selector4~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector4~0_combout\ = (\state.OFF_ST~q\ & (\Equal2~0_combout\ & !\Equal0~7_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \state.OFF_ST~q\,
	datac => \Equal2~0_combout\,
	datad => \Equal0~7_combout\,
	combout => \Selector4~0_combout\);

-- Location: LCCOMB_X21_Y27_N18
\Selector2~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector2~2_combout\ = (\state.WAIT_REL~q\ & (((\KEY[1]~input_o\)))) # (!\state.WAIT_REL~q\ & (\process_2~0_combout\ & ((\Selector13~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110001011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \process_2~0_combout\,
	datab => \state.WAIT_REL~q\,
	datac => \KEY[1]~input_o\,
	datad => \Selector13~0_combout\,
	combout => \Selector2~2_combout\);

-- Location: LCCOMB_X21_Y27_N20
\Selector2~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector2~3_combout\ = ((\state.IDLE~q\ & ((\Selector2~2_combout\))) # (!\state.IDLE~q\ & (!\KEY[1]~input_o\))) # (!\Selector2~1_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101111100011111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \KEY[1]~input_o\,
	datab => \state.IDLE~q\,
	datac => \Selector2~1_combout\,
	datad => \Selector2~2_combout\,
	combout => \Selector2~3_combout\);

-- Location: FF_X21_Y27_N3
\state.WAIT_REL\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \Selector4~0_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	ena => \Selector2~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \state.WAIT_REL~q\);

-- Location: LCCOMB_X21_Y27_N30
\Selector3~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector3~0_combout\ = (\state.WAIT_REL~q\ & \KEY[1]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \state.WAIT_REL~q\,
	datac => \KEY[1]~input_o\,
	combout => \Selector3~0_combout\);

-- Location: LCCOMB_X21_Y27_N26
\Selector1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector1~0_combout\ = (!\Selector3~0_combout\ & (\Selector2~1_combout\ & (\Selector3~2_combout\ & !\Selector3~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Selector3~0_combout\,
	datab => \Selector2~1_combout\,
	datac => \Selector3~2_combout\,
	datad => \Selector3~1_combout\,
	combout => \Selector1~0_combout\);

-- Location: FF_X21_Y27_N27
\state.LOAD\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \Selector1~0_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \state.LOAD~q\);

-- Location: LCCOMB_X21_Y27_N24
\Selector2~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \Selector2~0_combout\ = (\state.OFF_ST~q\ & ((\Equal0~7_combout\ & (\state.LOAD~q\)) # (!\Equal0~7_combout\ & ((!\Equal2~0_combout\))))) # (!\state.OFF_ST~q\ & (\state.LOAD~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \state.LOAD~q\,
	datab => \state.OFF_ST~q\,
	datac => \Equal2~0_combout\,
	datad => \Equal0~7_combout\,
	combout => \Selector2~0_combout\);

-- Location: FF_X21_Y27_N25
\state.ON_ST\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputclkctrl_outclk\,
	d => \Selector2~0_combout\,
	clrn => \KEY[0]~inputclkctrl_outclk\,
	ena => \Selector2~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \state.ON_ST~q\);

ww_LEDG(0) <= \LEDG[0]~output_o\;
END structure;


