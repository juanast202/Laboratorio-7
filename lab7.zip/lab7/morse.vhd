LIBRARY ieee;
USE ieee.std_logic_1164.all;
USE ieee.numeric_std.all;
 
ENTITY morse IS
    GENERIC ( HALF_SEC : natural := 25_000_000 );  -- ciclos de 50 MHz en 0.5 s
    PORT ( CLOCK_50 : IN  std_logic;
           KEY      : IN  std_logic_vector(1 downto 0);
           SW       : IN  std_logic_vector(2 downto 0);
           LEDG     : OUT std_logic_vector(0 downto 0) );
END morse;
 
ARCHITECTURE Behavior OF morse IS
 
    TYPE State_type IS (IDLE, LOAD, ON_ST, OFF_ST, WAIT_REL);
    SIGNAL state : State_type;
 
    -- Registro de desplazamiento Morse (0 = punto, 1 = raya), alineado a la izquierda
    SIGNAL shreg    : std_logic_vector(3 downto 0);
    -- Contador de longitud: simbolos que faltan por enviar
    SIGNAL remain   : unsigned(2 downto 0);
    -- Cuenta de medios segundos transcurridos dentro de una raya
    SIGNAL dur      : unsigned(1 downto 0);
    -- Contador de medio segundo
    SIGNAL cnt      : natural range 0 to HALF_SEC - 1;
    SIGNAL tick     : std_logic;
 
    -- Seleccion de letra (datos a cargar)
    SIGNAL code_sel : std_logic_vector(3 downto 0);
    SIGNAL len_sel  : unsigned(2 downto 0);
 
BEGIN
 
    ---------------------------------------------------------------
    -- Logica de seleccion de letra
    ---------------------------------------------------------------
    PROCESS (SW)
    BEGIN
        CASE SW IS
            WHEN "000"  => code_sel <= "0100"; len_sel <= to_unsigned(2, 3); -- A  .-
            WHEN "001"  => code_sel <= "1000"; len_sel <= to_unsigned(4, 3); -- B  -...
            WHEN "010"  => code_sel <= "1010"; len_sel <= to_unsigned(4, 3); -- C  -.-.
            WHEN "011"  => code_sel <= "1000"; len_sel <= to_unsigned(3, 3); -- D  -..
            WHEN "100"  => code_sel <= "0000"; len_sel <= to_unsigned(1, 3); -- E  .
            WHEN "101"  => code_sel <= "0010"; len_sel <= to_unsigned(4, 3); -- F  ..-.
            WHEN "110"  => code_sel <= "1100"; len_sel <= to_unsigned(3, 3); -- G  --.
            WHEN OTHERS => code_sel <= "0000"; len_sel <= to_unsigned(4, 3); -- H  ....
        END CASE;
    END PROCESS;
 
    ---------------------------------------------------------------
    -- Contador de medio segundo (se mantiene en 0 mientras no se transmite)
    ---------------------------------------------------------------
    PROCESS (CLOCK_50, KEY(0))
    BEGIN
        IF KEY(0) = '0' THEN
            cnt <= 0;
        ELSIF rising_edge(CLOCK_50) THEN
            IF state = IDLE OR state = LOAD OR state = WAIT_REL THEN
                cnt <= 0;
            ELSIF cnt = HALF_SEC - 1 THEN
                cnt <= 0;
            ELSE
                cnt <= cnt + 1;
            END IF;
        END IF;
    END PROCESS;
 
    tick <= '1' WHEN cnt = HALF_SEC - 1 ELSE '0';
 
    ---------------------------------------------------------------
    -- FSM + registro de desplazamiento + contador de longitud
    ---------------------------------------------------------------
    PROCESS (CLOCK_50, KEY(0))
    BEGIN
        IF KEY(0) = '0' THEN                 -- reset asincrono
            state  <= IDLE;
            shreg  <= (OTHERS => '0');
            remain <= (OTHERS => '0');
            dur    <= (OTHERS => '0');
        ELSIF rising_edge(CLOCK_50) THEN
            CASE state IS
 
                WHEN IDLE =>
                    IF KEY(1) = '0' THEN
                        state <= LOAD;
                    END IF;
 
                WHEN LOAD =>                 -- carga datos (Load = 1)
                    shreg  <= code_sel;
                    remain <= len_sel;
                    dur    <= (OTHERS => '0');
                    state  <= ON_ST;
 
                WHEN ON_ST =>                -- LED encendido
                    IF tick = '1' THEN
                        IF shreg(3) = '0' OR dur = 2 THEN   -- punto: 1 tick, raya: 3 ticks
                            dur   <= (OTHERS => '0');
                            state <= OFF_ST;
                        ELSE
                            dur <= dur + 1;
                        END IF;
                    END IF;
 
                WHEN OFF_ST =>               -- pausa de 0.5 s entre simbolos
                    IF tick = '1' THEN
                        shreg  <= shreg(2 downto 0) & '0';  -- siguiente simbolo (Enable)
                        remain <= remain - 1;
                        IF remain = 1 THEN
                            state <= WAIT_REL;
                        ELSE
                            state <= ON_ST;
                        END IF;
                    END IF;
 
                WHEN WAIT_REL =>             -- esperar a soltar KEY1
                    IF KEY(1) = '1' THEN
                        state <= IDLE;
                    END IF;
 
            END CASE;
        END IF;
    END PROCESS;
 
    -- Salida tipo Moore
    LEDG(0) <= '1' WHEN state = ON_ST ELSE '0';
 
END Behavior;